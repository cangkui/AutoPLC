#include <stdbool.h>
#include <stdint.h>
#include <assert.h>
#include <math.h>

// Declare nondet assignment functions
bool nondet_bool();
uint8_t nondet_uint8_t();
uint16_t nondet_uint16_t();
uint32_t nondet_uint32_t();
uint64_t nondet_uint64_t();
int8_t nondet_int8_t();
int16_t nondet_int16_t();
int32_t nondet_int32_t();
int64_t nondet_int64_t();
double nondet_float();
double nondet_double();

// Root data structure
typedef struct {
	int16_t i;
	int16_t j;
	bool flag;
	int16_t count;
	int16_t some_var;
} __FB_NestedLoopControl;

// Global variables
__FB_NestedLoopControl instance;
bool EoC;
bool BoC;
bool __cbmc_boc_marker;
bool __cbmc_eoc_marker;

// Automata declarations
void FB_NestedLoopControl(__FB_NestedLoopControl *__context);
void VerificationLoop();

// Automata
void FB_NestedLoopControl(__FB_NestedLoopControl *__context) {
	// Temporary variables
	
	// Start with initial location
	goto init;
	init: {
			__context->i = 0;
			goto l19;
		//assert(false);
		return;  			}
	l2: {
		if (__context->flag) {
			goto l11;
		}
		if ((! __context->flag)) {
			goto l6;
		}
		//assert(false);
		return;  			}
	l6: {
		if ((__context->count < 506)) {
			__context->count = (__context->count + 1);
			goto l10;
		}
		if ((! (__context->count < 506))) {
			goto l10;
		}
		//assert(false);
		return;  			}
	l10: {
			__context->j = (__context->j + 2);
			goto l12;
		//assert(false);
		return;  			}
	l11: {
		if (__context->flag) {
			goto l18;
		}
		if ((! __context->flag)) {
			__context->i = (__context->i + 1);
			goto l19;
		}
		//assert(false);
		return;  			}
	l12: {
		if ((__context->j <= 100)) {
			goto l2;
		}
		if ((! (__context->j <= 100))) {
			goto l11;
		}
		//assert(false);
		return;  			}
	l18: {
		goto __end_of_automaton;
		//assert(false);
		return;  			}
	l19: {
		if ((__context->i <= 10)) {
			__context->j = 10;
			goto l12;
		}
		if ((! (__context->i <= 10))) {
			goto l18;
		}
		//assert(false);
		return;  			}
	
	// End of automaton
	__end_of_automaton: ;
}
void VerificationLoop() {
	// Temporary variables
	
	// Start with initial location
	goto init1;
	init1: {
			goto loop_start;
		//assert(false);
		return;  			}
	end: {
		goto __end_of_automaton;
		//assert(false);
		return;  			}
	loop_start: {
			BoC = true;
			goto prepare_BoC;
		if (false) {
			goto end;
		}
		//assert(false);
		return;  			}
	prepare_BoC: {
		__cbmc_boc_marker = true; // to indicate the beginning of the loop for the counterexample parser
		__cbmc_boc_marker = false;
			BoC = false;
			goto l_main_call;
		//assert(false);
		return;  			}
	l_main_call: {
			// Assign inputs
			FB_NestedLoopControl(&instance);
			// Assign outputs
			goto callEnd;
		//assert(false);
		return;  			}
	callEnd: {
			EoC = true;
			goto prepare_EoC;
		//assert(false);
		return;  			}
	prepare_EoC: {
		assert((!(EoC) || ((instance.i >= 0) && (instance.i <= 10))));
		__cbmc_eoc_marker = true; // to indicate the end of the loop for the counterexample parser
		__cbmc_eoc_marker = false;
			EoC = false;
			goto loop_start;
		//assert(false);
		return;  			}
	
	// End of automaton
	__end_of_automaton: ;
}

// Main
void main() {
	// Initial values
	instance.i = 0;
	instance.j = 0;
	instance.flag = false;
	instance.count = 0;
	instance.some_var = 0;
	EoC = false;
	BoC = false;
	
	VerificationLoop();
}

